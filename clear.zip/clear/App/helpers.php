<?php

/** * Retorna o diretório das views */
function viewsPath()
{
  return BASE_PATH .DIRECTORY_SEPARATOR . 'App' . DIRECTORY_SEPARATOR . 'Views' . DIRECTORY_SEPARATOR;
}


function uploadImage($file, $nomeImg, $idUser, $tipo = ''){

if (!file_exists('img/'.$idUser)) {
    mkdir('img/'.$idUser, 0777, true);
}

$target_file = $nomeImg;

  if (move_uploaded_file($file["foto"]["tmp_name"], $target_file)) {
    return 1;
  } else {
    return 0; 
   }



}
