<?php

namespace App\Controllers;
use \raelgc\view\Template;
use App\Models\clsFaxineira;


class homeController
{
    /**
     * Renderiza a página de cadastro.
     */
    public static function home(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/home/home.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }
    public static function login(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/login.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }
    public static function cadastro(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/cadastro.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }
    public static function procurar($cidade, $nomeCidade){
        
        $faxineira = new clsFaxineira();
        $result = $faxineira::listarPorCidade($cidade);

 
  

        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/procurar.html");
        $t->addFile('footer', viewsPath() . "/footer.html");

            $t->cidade = $nomeCidade;
   


        if($result){
        foreach($result as $faxineira){
            $t->block('BLOCK_FAXINEIRA');
            $t->nome = $faxineira['nome'];
            $t->informacoes = $faxineira['informacao'];
            $t->telefone = $faxineira['telefone'];
            $t->foto =  $faxineira['foto'];
        }
        }else{
            $t->block('BLOCK_SEM_FAXINEIRA');

        }

        $t->show();
    }
    public static function procurarPorCidade(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/procurar-por-cidade.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }
 
    public static function termo(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/termo.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }
    public static function avaliacao(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/avaliacao.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }
    public static function naoCadastrado(){
        
        $t = new Template(viewsPath() . "/header.html");
        $t->addFile('body', viewsPath() . "/painel/naoCadastrado.html");
        $t->addFile('footer', viewsPath() . "/footer.html");
        $t->show();
    }

    
}