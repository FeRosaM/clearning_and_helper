<?php

namespace App\Controllers;
use \raelgc\view\Template;
use App\Models\clsFaxineira;

class faxineiraController
{
    /**
     * Renderiza a página de cadastro.
     */
    public static function logar($email, $senha){
        $faxineira = new clsFaxineira();
        $result = $faxineira::logar($email, $senha);
       
        if($result){
            $_SESSION['id'] = $result['id_faxineira'];
            echo '1';
            exit;

        }else{
             echo '0';
            exit;
    } 

} 



    public static function cadastrar($params, $file){
        $faxineira = new clsFaxineira();
        if($result = $faxineira::cadastrarFaxineira($params)){
            $nomeImg = "img/". $result."/".$result."-perfil-".microtime(true).".jpg";
            if(uploadImage($file, $nomeImg, $result)){

                $faxineira::cadastrarFotoPerfil($result, $nomeImg);

                header("Location/perfil/");
                exit;

            }else{
                print_r('usuario nao cadastrado');                
            }

        }


 }

 public static function perfil(){
    
    $faxineira = new clsFaxineira();
    $result = $faxineira::carregarDados($_SESSION['id']);


    $t = new Template(viewsPath() . "/header.html");
    $t->addFile('body', viewsPath() . "/painel/perfil.html");
    $t->addFile('footer', viewsPath() . "/footer.html");


    $t->nome = $result['nome'];
    $t->tel = $result['telefone'];
    $t->cidade = $result['cidade'];
    $t->email= $result['email'];
    $t->informacoes= $result['informacao'];
    $t->foto= $result['foto'];


    





    $t->show();
}
 
}
