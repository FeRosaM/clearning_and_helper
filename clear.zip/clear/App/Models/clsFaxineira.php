<?php
namespace App\Models;

use PDO;

use App\Models\clsBD;


class clsFaxineira {
    private $db;

    public function __construct() {
        $this->db = new clsBD();

    }

    public static function logar($email, $senha) {
        $db = new clsBD();

        $result =  $db->select('faxineira', ['email' => $email], '*', 'AND', 'id_faxineira DESC', '1');
        if ($result) {
            // Pega o hash da senha do banco
            $hash = $result[0]['senha'];
            // Verifica se a senha digitada é válida
            if (password_verify($senha, $hash)) {
                return  $result[0];
            }else{
                return null;
            }
        }else{
            return null;
 
        }
    }

    

    public static function cadastrarFaxineira($param) {
        $db = new clsBD();

        $result =  $db->insertAndGetId('faxineira', ['nome' => $param['nome'], 'senha' => password_hash($param['senha'], PASSWORD_DEFAULT) , 'email' => $param['email'], 'cidade' => $param['cidade']], '*', 'AND', 'id_faxineira DESC', '1');

        return !empty($result) ? $result : null;
    }




    public static function cadastrarFotoPerfil($id, $nomeFoto) {
        $db = new clsBD();

        return $db->update('faxineira', ['foto' => $nomeFoto], ['id_faxineira' => $id]);
        
    }


    public static function carregarDados($id){
        $db = new clsBD();

        $result =  $db->select('faxineira', ['id_faxineira' => $id], '*', '', '', '');
        if ($result) {
            return $result[0];
        }else{
            return false;
        }

    }

    public static function listarPorCidade($cidade){
        $db = new clsBD();

        $result =  $db->select('faxineira', ['cidade' => $cidade], '*', '', 'id_faxineira DESC', '');
        if ($result) {
            return $result;
        }else{
            return false;
        }

    }

   


}

