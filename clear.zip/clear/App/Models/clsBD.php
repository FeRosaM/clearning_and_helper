<?php
namespace App\Models;

use PDO;
use PDOException;

class clsBD {
    private $db;
    private $host = 'localhost';
    private $dbname = 'cleaning_and_helper';
    private $username = 'root';
    private $password = '';

    public function __construct(){

        try {
            $this->db = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8mb4", $this->username, $this->password);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->db->exec("SET NAMES 'utf8mb4'");

        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
            
        }

    }

    public function insert($table, $data) {
        $columns = implode(", ", array_keys($data));
        $placeholders = ":" . implode(", :", array_keys($data));
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function insertAndGetId($table, $data) {
    try{
        $columns = implode(", ", array_keys($data));
        $placeholders = ":" . implode(", :", array_keys($data));
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $this->db->prepare($sql);
        if ($stmt->execute($data)) {
            return $this->db->lastInsertId();
        } else {
            return false;
        }
    } catch (PDOException $e) {
        return false;
        
    }
    }


    public function select($table, $conditions = [], $columns = '*', $logicalOperator = 'AND', $orderBy = '', $limit = '') {
        $sql = "SELECT $columns FROM $table";
    
        
        if (!empty($conditions)) {
            $conditionString = $this->buildConditionString($conditions, $logicalOperator);
            if (!empty($conditionString)) {
                $sql .= " WHERE " . $conditionString;
            }
        }
    
        if (!empty($orderBy)) {
            $sql .= " ORDER BY $orderBy";
        }
    
        if (!empty($limit)) {
            $sql .= " LIMIT $limit";
        }
    
      
        // Para depuração, verifique o SQL gerado
        error_log($sql);
    
        $stmt = $this->db->prepare($sql);
        $this->bindValues($stmt, $conditions);


        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    

    public function update($table, $data, $conditions, $logicalOperator = 'AND') {
        // Construir a string de atualização
        $columns = implode(", ", array_map(function($key) {
            return "$key = :$key";
        }, array_keys($data)));
    
        // Construir a string de condição
        $conditionString = implode(" $logicalOperator ", array_map(function($key) {
            return "$key = :cond_$key";
        }, array_keys($conditions)));
    
        // Montar a query
        $sql = "UPDATE $table SET $columns WHERE $conditionString";

        $stmt = $this->db->prepare($sql);
    
        // Vincular valores para a condição
        foreach ($conditions as $key => $value) {
            $stmt->bindValue(":cond_$key", $value);
        }
    
        // Vincular valores para os dados
        foreach ($data as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
    
        // Executar a query
        $result = $stmt->execute();
        return $result;
    }
    

    public function delete($table, $conditions, $logicalOperator = 'AND') {
        $sql = "DELETE FROM $table WHERE " . $this->buildConditionString($conditions, $logicalOperator);
        $stmt = $this->db->prepare($sql);
        $this->bindValues($stmt, $conditions);
        return $stmt->execute();
    }

    private function buildConditionString($conditions, $logicalOperator = 'AND') {
        $conditionStrings = [];
        foreach ($conditions as $key => $value) {
            if (strpos($key, ' ') !== false) {
                list($column, $operator) = explode(' ', $key, 2);
                $conditionStrings[] = "$column $operator :$column";
            } else {
                $conditionStrings[] = "$key = :$key";
            }
        }
        return implode(" $logicalOperator ", $conditionStrings);
    }
    
    
    

    private function bindValues($stmt, $conditions) {
        foreach ($conditions as $key => $value) {
            if (strpos($key, ' ') !== false) {
                list($column, $operator) = explode(' ', $key, 2);
            } else {
                $column = $key;
            }
            $stmt->bindValue(":$column", $value);
        }
    }
    
    public function getConnection() {
        return $this->db;
    }
}
