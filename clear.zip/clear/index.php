<?php
require "init.php";
session_start();
use Slim\Factory\AppFactory;
use Slim\Psr7\Response;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Exception\HttpNotFoundException;
use App\Controllers\homeController;
use App\Controllers\faxineiraController;


$app = AppFactory::create();

// Add Routing Middleware 
$app->addRoutingMiddleware();

// Middleware executado antes do request ser tratado.
$beforeMiddleware = function (ServerRequestInterface $request, RequestHandlerInterface $handler) {
    $response = $handler->handle($request);
    $existingContent = (string) $response->getBody();
    $response = new Response();
    return $response;
};

// Middleware executado após o request ser tratado.
$afterMiddleware = function (ServerRequestInterface $request, RequestHandlerInterface $handler) {
    $response = $handler->handle($request);
    return $response;
};

// Adiciona os middlewares à aplicação.
$app->add($beforeMiddleware);
$app->add($afterMiddleware);

$beforeMiddleware = function (ServerRequestInterface $request, RequestHandlerInterface $handler) {
    $response = $handler->handle($request);
    $existingContent = (string) $response->getBody();
    $response = new Response();
    return $response;
};

// Middleware executado após o request ser tratado.
$afterMiddleware = function (ServerRequestInterface $request, RequestHandlerInterface $handler) {
    $response = $handler->handle($request);
    return $response;
};

// Adiciona os middlewares à aplicação.
$app->add($beforeMiddleware);
$app->add($afterMiddleware);


$app->addErrorMiddleware(true, true, false);

//função para definir as rotas/url
$app->get('[/]', function ($request, $response, $args) {

    homeController::home();
    return $response;
});
$app->get('/login[/]', function ($request, $response, $args) {

    homeController::login();
    return $response;
});
$app->get('/cadastro[/]', function ($request, $response, $args) {

    homeController::cadastro();
    return $response;
});
$app->post('/procurar[/]', function ($request, $response, $args) {

    homeController::procurar($_POST['cidade'], $_POST['nomeCidade']);
    return $response;

});

$app->get('/procurar-por-cidade[/]', function ($request, $response, $args) {

    homeController::procurarPorCidade();
    return $response;
});
$app->get('/painel/perfil[/]', function ($request, $response, $args) {

    if(!isset($_SESSION['id']))
             header("Location: /login");  
    
    faxineiraController::perfil();
    return $response;
});
$app->get('/termo[/]', function ($request, $response, $args) {

    homeController::termo();
    return $response;
});
$app->get('/avaliacao[/]', function ($request, $response, $args) {

    homeController::avaliacao();
    return $response;
});
$app->get('/naoCadastrado[/]', function ($request, $response, $args) {

    homeController::naoCadastrado();
    return $response;
});
$app->post('/logar[/]', function ($request, $response, $args) {
   
        faxineiraController::logar($_POST['email'], $_POST['senha']);
    return $response;
});


$app->post('/cadastrar[/]', function ($request, $response, $args) {

    if($_POST['tipouser'] == '1')
        faxineiraController::cadastrar($_POST, $_FILES);
    if($_POST['tipouser'] == '2')
        contratanteController::cadastrar($_POST, $_FILES);
    return $response;
});

$app->run();
